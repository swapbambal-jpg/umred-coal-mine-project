<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Menu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class MenuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $query = Menu::with(['children', 'parent']);

        if ($request->boolean('active_only')) {
            $query->where('is_active', true);
        }

        if ($request->boolean('root_only')) {
            $query->whereNull('parent_id');
        }

        $menus = $query->orderBy('sort_order')->orderBy('name')->get();
        
        return response()->json([
            'success' => true,
            'data' => $menus,
            'message' => 'Menus retrieved successfully'
        ], 200);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'url' => 'nullable|string|max:255',
            'icon' => 'nullable|string|max:255',
            'parent_id' => 'nullable|exists:menus,id',
            'sort_order' => 'nullable|integer|min:0',
            'is_active' => 'required|boolean'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation Error',
                'errors' => $validator->errors()
            ], 422);
        }

        $menu = Menu::create([
            'name' => $request->name,
            'url' => $request->url,
            'icon' => $request->icon,
            'parent_id' => $request->parent_id,
            'sort_order' => $request->sort_order ?? 0,
            'is_active' => $request->is_active
        ]);

        return response()->json([
            'success' => true,
            'data' => $menu->load(['children', 'parent']),
            'message' => 'Menu created successfully'
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $menu = Menu::find($id);

        if (!$menu) {
            return response()->json([
                'success' => false,
                'message' => 'Menu not found'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $menu->load(['children', 'parent']),
            'message' => 'Menu retrieved successfully'
        ], 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $menu = Menu::find($id);

        if (!$menu) {
            return response()->json([
                'success' => false,
                'message' => 'Menu not found'
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'url' => 'nullable|string|max:255',
            'icon' => 'nullable|string|max:255',
            'parent_id' => 'nullable|exists:menus,id',
            'sort_order' => 'nullable|integer|min:0',
            'is_active' => 'required|boolean'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation Error',
                'errors' => $validator->errors()
            ], 422);
        }

        $menu->update([
            'name' => $request->name,
            'url' => $request->url,
            'icon' => $request->icon,
            'parent_id' => $request->parent_id,
            'sort_order' => $request->sort_order ?? $menu->sort_order,
            'is_active' => $request->is_active
        ]);

        return response()->json([
            'success' => true,
            'data' => $menu->load(['children', 'parent']),
            'message' => 'Menu updated successfully'
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $menu = Menu::find($id);

        if (!$menu) {
            return response()->json([
                'success' => false,
                'message' => 'Menu not found'
            ], 404);
        }

        if ($menu->children()->exists()) {
            return response()->json([
                'success' => false,
                'message' => 'Cannot delete menu with child items. Please delete or move children first.'
            ], 422);
        }

        $menu->delete();

        return response()->json([
            'success' => true,
            'message' => 'Menu deleted successfully'
        ], 200);
    }

    /**
     * Get menu tree structure
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function tree(Request $request)
    {
        $query = Menu::whereNull('parent_id')
            ->with(['children' => function ($query) {
                $query->where('is_active', true)->with(['children']);
            }]);

        if ($request->boolean('active_only', true)) {
            $query->where('is_active', true);
        }

        $menus = $query->orderBy('sort_order')->orderBy('name')->get();

        return response()->json([
            'success' => true,
            'data' => $menus,
            'message' => 'Menu tree retrieved successfully'
        ], 200);
    }

    /**
     * Toggle menu status
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function toggleStatus($id)
    {
        $menu = Menu::find($id);

        if (!$menu) {
            return response()->json([
                'success' => false,
                'message' => 'Menu not found'
            ], 404);
        }

        $menu->update(['is_active' => !$menu->is_active]);

        return response()->json([
            'success' => true,
            'data' => $menu,
            'message' => "Menu " . ($menu->is_active ? 'activated' : 'deactivated') . " successfully"
        ], 200);
    }

    /**
     * Get parent menu list
     *
     * @return \Illuminate\Http\Response
     */
    public function getParentMenuList()
    {
        $parentMenus = Menu::whereNull('parent_id')
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->orderBy('name')
            ->select('id', 'name')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $parentMenus,
            'message' => 'Parent menus retrieved successfully'
        ], 200);
    }

    /**
     * Get parent and submenu list
     *
     * @param  int  $roleId
     * @return \Illuminate\Http\Response
     */
    public function getParentSubmenuList($roleId)
    {
        $parentMenus = Menu::whereNull('parent_id')
            ->where('is_active', true)
            ->leftJoin('role_menu_permissions', function($join) use ($roleId) {
                $join->on('menus.id', '=', 'role_menu_permissions.menu_id')
                     ->where('role_menu_permissions.role_id', '=', $roleId);
            })
            ->with(['children' => function ($query) {
                $query->where('is_active', true)
                    ->orderBy('sort_order')
                    ->orderBy('name')
                    ->select('id', 'name', 'parent_id', 'route', 'icon');
            }])
            ->groupBy('menus.id', 'menus.name', 'menus.route', 'menus.icon', 'role_menu_permissions.is_parent')
            ->orderBy('sort_order')
            ->orderBy('name')
            ->select('menus.id', 'menus.name', 'menus.route', 'menus.icon', 'role_menu_permissions.is_parent')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $parentMenus,
            'message' => 'Parent and submenu list retrieved successfully'
        ], 200);
    }
}
